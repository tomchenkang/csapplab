#define Msize 13

void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, ib, jb, ih, jh, bsize = 4, tmp;

    for (i = 0; i < N; i += bsize)
    {
        for (j = 0; j < M; j += bsize)
        {
            tmp = ib + bsize;
            ih = tmp < N ? tmp : N;
            tmp = jb + bsize;
            jh = tmp < M ? tmp : M;

            for (ib = i; ib < ih; ib++)
            {
                for (jb = j; jb < jh; jb++)
                {
                    tmp = A[ib][jb];
                    B[jb][ib] = tmp;
                }
            }
        }
    }
}

int main(int argc, char const *argv[])
{
    int A[Msize][Msize], B[Msize][Msize];

    for (int i = 0; i < Msize; i++)
    {
        for (int j = 0; j < Msize; j++)
        {
            A[i][j] = i * Msize + j;
        }
    }

    transpose_submit(Msize, Msize, A, B);

    return 0;
}
