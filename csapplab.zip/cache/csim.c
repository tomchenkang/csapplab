#include "cachelab.h"
#include <getopt.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
/* 
trace file format:
	operation   address     size
	I   :   instruction load
	M   :   data modify     (treated as a load + store)
	L   :   data load
	S   :   data store
	s, E, b
	it use LRU(least-recently used) replacement policy
 */

typedef struct node *Ptrnext;
struct node
{
	long long data;
	Ptrnext next;
} Ma[256];
Ptrnext tnode1, tnode2;
int hits, misses, evictions, flag = 0;

void initial()
{
	for (size_t i = 0; i < 256; i++)
	{
		Ma[i].data = 0;
		Ma[i].next = NULL;
	}
}

int search(int E, int start, long long num)
{
	tnode1 = &Ma[start];
	tnode2 = tnode1->next;
	Ptrnext newnode;

	while (tnode2) /* search the node */
	{
		if (tnode2->data == num)
		{
			tnode1->next = tnode2->next;
			tnode2->next = Ma[start].next;
			Ma[start].next = tnode2;
			return 0;
		}
		else if (tnode2->next == NULL)
			break;
		else
		{
			tnode1 = tnode2;
			tnode2 = tnode2->next;
		}
	}
	if (tnode2 == NULL)
	{
		newnode = (Ptrnext)malloc(sizeof(struct node));
		newnode->data = num;
		newnode->next = NULL;
		Ma[start].next = newnode;
		Ma[start].data++;
		return 2;
	}
	else /* cannot find node */
	{
		if (Ma[start].data == E) /* block eviction */
		{
			tnode1->next = NULL;
			tnode2->data = num;
			tnode2->next = Ma[start].next;
			Ma[start].next = tnode2;
			return 1;
		}
		else /* just miss */
		{
			newnode = (Ptrnext)malloc(sizeof(struct node));
			newnode->data = num;
			newnode->next = Ma[start].next;
			Ma[start].next = newnode;
			Ma[start].data++;
			return 2;
		}
	}
}

void load(int E, int start, long long num)
{
	int temp;

	temp = search(E, start, num);
	if (!temp)
	{
		if (flag)
			printf("hit\n");
		hits++;
	}
	else if (temp == 1)
	{
		if (flag)
			printf("miss eviction\n");
		misses++;
		evictions++;
	}
	else
	{
		if (flag)
			printf("miss\n");
		misses++;
	}
}

void store(int E, int start, long long num)
{
	int temp;

	temp = search(E, start, num);
	if (!temp)
	{
		if (flag)
			printf("hit\n");
		hits++;
	}
	else if (temp == 1)
	{
		if (flag)
			printf("miss eviction\n");
		misses++;
		evictions++;
	}
	else
	{
		if (flag)
			printf("miss\n");
		misses++;
	}
}
void modify(int E, int start, long long num)
{
	int temp;

	temp = search(E, start, num);
	if (!temp)
	{
		if (flag)
			printf("hit hit\n");
		hits += 2;
	}
	else if (temp == 1)
	{
		if (flag)
			printf("miss eviction hit\n");
		hits++;
		evictions++;
		misses++;
	}
	else
	{
		if (flag)
			printf("miss hit\n");
		misses++;
		hits++;
	}
}

int main(int argc, char *argv[])
{
	char c, str[4];
	int s, E, b, rsize;
	long long addr, t1, t2, ssize = 0, bsize = 0;
	FILE *fp;

	while ((c = getopt(argc, argv, "vs:E:b:t:")) != -1)
	{
		switch (c)
		{
		case 's':
			s = atoi(optarg);
			break;
		case 'E':
			E = atoi(optarg);
			break;
		case 'b':
			b = atoi(optarg);
			break;
		case 't':
			if ((fp = fopen(optarg, "r")) == NULL)
			{
				printf("cannot open file %s\n", optarg);
				exit(1);
			}
			break;
		case 'v':
			flag = 1;
			break;
		default:
			printf("./csim failed to parse its options.\n");
			exit(1);
		}
	}
	hits = misses = evictions = 0;
	initial();
	ssize = (1 << (s + b)) - 1;
	bsize = (~0) << b;
	while (!feof(fp))
	{
		fscanf(fp, "%s %llx,%d\n", str, &addr, &rsize);

		t1 = (addr & ssize) >> b;
		t2 = addr & bsize;
		switch (str[0])
		{
		case 'L':
			if (flag)
				printf("%c %llx,%d ", str[0], addr, rsize);
			load(E, t1, t2);
			break;
		case 'S':
			if (flag)
				printf("%c %llx,%d ", str[0], addr, rsize);
			store(E, t1, t2);
			break;
		case 'M':
			if (flag)
				printf("%c %llx,%d ", str[0], addr, rsize);
			modify(E, t1, t2);
			break;
		default:
			break;
		}
	}
	fclose(fp);
	printSummary(hits, misses, evictions);
	return 0;
}
