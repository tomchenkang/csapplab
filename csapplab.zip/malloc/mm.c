/*
 * mm-naive.c - The fastest, least memory-efficient malloc package.
 * 
 * In this naive approach, a block is allocated by simply incrementing
 * the brk pointer.  A block is pure payload. There are no headers or
 * footers.  Blocks are never coalesced or reused. Realloc is
 * implemented directly using mm_malloc and mm_free.
 *
 * NOTE TO STUDENTS: Replace this header comment with your own header
 * comment that gives a high level description of your solution.
 */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>
#include <string.h>

#include "mm.h"
#include "memlib.h"

/*********************************************************
 * NOTE TO STUDENTS: Before you do anything else, please
 * provide your team information in the following struct.
 ********************************************************/
team_t team = {
	/* Team name */
	"ateam",
	/* First member's full name */
	"Harry Bovik",
	/* First member's email address */
	"bovik@cs.cmu.edu",
	/* Second member's full name (leave blank if none) */
	"",
	/* Second member's email address (leave blank if none) */
	""};

/* single word (4) or double word (8) alignment */
#define ALIGNMENT 8
#define MAXLIST 16
/* rounds up to the nearest multiple of ALIGNMENT */
#define ALIGN(size) (((size) + (ALIGNMENT - 1)) & ~0x7)

#define SIZE_T_SIZE (ALIGN(sizeof(size_t)))

/*********************************************************
 * basic constants and macros reference from book page 599
 *  
 ********************************************************/
//#define Mode
#define WSIZE 4
#define DSIZE 8
#define CHUNKSIZE (1 << 12) // extend size

#define MAX(x, y) ((x) > (y) ? (x) : (y))

// pack a size and allocated bit into a word
#define PACK(size, alloc) ((size) | (alloc))
// read or write a word at address p
#define GET(p) (*(unsigned int *)(p))
#define PUT(p, val) (*(unsigned int *)(p) = (val))
// get the size && allocated fields of address p
#define GET_SIZE(p) (*(unsigned int *)(p) & ~0x7)
#define GET_ALLO(p) (*(unsigned int *)(p)&0x1)
// compute header && footer address of the block
#define HDRP(bp) ((char *)(bp)-WSIZE)
#define FTRP(bp) ((char *)(bp) + GET_SIZE(HDRP(bp)) - DSIZE)
// compute address of the next && previous block
#define NEXT_BLKP(bp) ((char *)(bp) + GET_SIZE(HDRP(bp)))
#define PREV_BLKP(bp) ((char *)(bp)-GET_SIZE((char *)(bp)-DSIZE))
// get the block pre && success block address
#define PRED_PTR(ptr) ((char *)(ptr))
#define SUCC_PTR(ptr) ((char *)(ptr) + WSIZE)
// get the store info int ptr
#define PRED(ptr) (*(char **)(ptr))
#define SUCC(ptr) (*(char **)(SUCC_PTR(ptr)))
// set ptr to p to store the pointer information
#define SET_PTR(p, ptr) (*(unsigned int *)(p) = (unsigned int)(ptr))

/* adjacent link list to store the free nodes */
void *segregated_free_lists[MAXLIST];
static char *heap_listp;
static void *extend_heap(size_t words);
static void *coalesce(void *bp);
//static void *first_fit(size_t asize);
//static void *best_fit(size_t asize);
static void *place(void *bp, size_t asize);
static void insert(void *ptr, size_t size);
static void delete (void *ptr);

/* 
 * mm_init - initialize the malloc package.
 */
int mm_init(void)
{
	for (size_t i = 0; i < MAXLIST; i++)
	{
		segregated_free_lists[i] = NULL;
	}

	if ((heap_listp = mem_sbrk(4 * WSIZE)) == (void *)-1)
		return -1;

	PUT(heap_listp, 0);							   // alignment padding
	PUT(heap_listp + (1 * WSIZE), PACK(DSIZE, 1)); // header
	PUT(heap_listp + (2 * WSIZE), PACK(DSIZE, 1)); // footer
	PUT(heap_listp + (3 * WSIZE), PACK(0, 1));	   // 结尾块

	if (extend_heap(CHUNKSIZE) == NULL) //extend the empty heap
		return -1;

	return 0;
}

/* 
 * mm_malloc - Allocate a block by incrementing the brk pointer.
 *     Always allocate a block whose size is a multiple of the alignment.
 */
void *mm_malloc(size_t size)
{
	size_t asize, tsize, pos = 0;
	void *bp = NULL;

	if (size == 0)
		return NULL;
	if (size <= DSIZE)	// the smallest block
		asize = 2 * DSIZE;
	else
		asize = DSIZE * ((size + (DSIZE) + (DSIZE - 1)) / DSIZE);//allign

	tsize = asize;
	while (tsize > 1)	// find position in segregate_free_list
	{
		tsize >>= 1;
		pos++;
	}
	for (; pos < MAXLIST; pos++)
	{
		bp = segregated_free_lists[pos];
		while ((bp != NULL) && asize > GET_SIZE(HDRP(bp)))
		{
			bp = PRED(bp);
		}
		if (bp)
			break;
	}

	if (bp == NULL)//cannot find a fit free fraction
	{
		if ((bp = extend_heap(MAX(CHUNKSIZE, asize))) == NULL)
			return NULL;
	}

	bp = place(bp, asize);//if the fraction can cause internal fraction we need to divide it
	return bp;
}

/*
 * mm_free - Freeing a block does nothing.
 */
void mm_free(void *ptr)
{
	size_t size = GET_SIZE(HDRP(ptr));

	PUT(HDRP(ptr), PACK(size, 0));
	PUT(FTRP(ptr), PACK(size, 0));

	insert(ptr, size);
	coalesce(ptr);	//pudding the free block
	return;
}

/*
 * mm_realloc - Implemented simply in terms of mm_malloc and mm_free
 */
void *mm_realloc(void *ptr, size_t size)
{
	size_t asize, ptr_size = 0;
	void *newptr= ptr;

	if (ptr == NULL) // case 1
		return mm_malloc(size);
	if (size == 0) // case 2
	{
		mm_free(ptr);
		return NULL;
	}

	/* allign to 1 word */
	asize = size <= DSIZE ? 2 * DSIZE : DSIZE * ((size + (DSIZE) + (DSIZE - 1)) / DSIZE);

	if (GET_SIZE(HDRP(ptr)) >= asize)
		return ptr;
	/* the next one is the heap end or a free block */
	else if (!GET_ALLO(HDRP(NEXT_BLKP(ptr))) || !GET_SIZE(HDRP(NEXT_BLKP(ptr))))
	{
		ptr_size = GET_SIZE(HDRP(ptr)) + GET_SIZE(HDRP(NEXT_BLKP(ptr)));
		
		if (ptr_size < asize)
		{
			if (extend_heap(MAX(asize - ptr_size, CHUNKSIZE)) == NULL)
				return NULL;
			ptr_size += MAX(asize - ptr_size, CHUNKSIZE);
		}

		delete(NEXT_BLKP(ptr));
		PUT(HDRP(ptr), PACK(ptr_size, 1));
		PUT(FTRP(ptr), PACK(ptr_size, 1));
	}
	/* malloc a new block && copy the date to newblock */
	else
	{
		newptr = mm_malloc(asize);
		memcpy(newptr, ptr, GET_SIZE(HDRP(ptr)));
		mm_free(ptr);
	}
	return newptr;
}

static void *extend_heap(size_t words)
{
	char *bp;
	size_t size;

	size = ALIGN(words); //对齐
	if ((long)(bp = mem_sbrk(size)) == -1)
		return NULL;

	PUT(HDRP(bp), PACK(size, 0));		  //header is the last block end word
	PUT(FTRP(bp), PACK(size, 0));		  //footer
	PUT(HDRP(NEXT_BLKP(bp)), PACK(0, 1)); //新的结尾块

	insert(bp, size);
	return coalesce(bp);
}

static void insert(void *ptr, size_t size)
{
	size_t pos = 0;
	void *pre = NULL, *next = NULL;

	while (pos < MAXLIST - 1 && size > 1)
	{
		size >>= 1;
		pos++;
	}

	next = segregated_free_lists[pos];	//it store the end node
	if (next == NULL) // the list is NULL
	{
		SET_PTR(PRED_PTR(ptr), NULL);
		SET_PTR(SUCC_PTR(ptr), NULL);
		segregated_free_lists[pos] = ptr;
		return;
	}

	pre = PRED(next);
	while (pre != NULL && (size > GET_SIZE(HDRP(pre))))//we search from end to head
	{
		next = pre;
		pre = PRED(pre);
	}

	if (size < GET_SIZE(HDRP(next))) // the insert position is the end
	{
		SET_PTR(PRED_PTR(ptr), next);
		SET_PTR(SUCC_PTR(ptr), NULL);
		SET_PTR(SUCC_PTR(next), ptr);
		segregated_free_lists[pos] = ptr;
	}
	else if (pre == NULL) // the inset position is the head
	{
		SET_PTR(PRED_PTR(ptr), NULL);
		SET_PTR(SUCC_PTR(ptr), next);
		SET_PTR(PRED_PTR(next), ptr);
	}
	else // the insert postion is between nodes
	{
		SET_PTR(PRED_PTR(ptr), pre);
		SET_PTR(SUCC_PTR(ptr), next);
		SET_PTR(PRED_PTR(next), ptr);
		SET_PTR(SUCC_PTR(pre), ptr);
	}
}

static void delete (void *ptr)
{
	size_t pos = 0, size;

	size = GET_SIZE(HDRP(ptr));
	while (pos < MAXLIST - 1 && size > 1)
	{
		size >>= 1;
		pos++;
	}

	if (PRED(ptr) == NULL)
	{
		if (SUCC(ptr) == NULL)
		{
			segregated_free_lists[pos] = NULL;//only one node
		}
		else
		{
			SET_PTR(PRED_PTR(SUCC(ptr)), NULL);//the head node
		}
	}
	else
	{
		if (SUCC(ptr) == NULL)
		{
			SET_PTR(SUCC_PTR(PRED(ptr)), NULL);
			segregated_free_lists[pos] = PRED(ptr);//the end node
		}
		else
		{
			SET_PTR(PRED_PTR(SUCC(ptr)), PRED(ptr));
			SET_PTR(SUCC_PTR(PRED(ptr)), SUCC(ptr));//the mid node
		}
	}
}

/*
 * mm_realloc - coalesce the adjecent block
 */
static void *coalesce(void *bp)
{
	size_t prev_alloc = GET_ALLO(FTRP(PREV_BLKP(bp))); //check previous block been allocated or not
	size_t next_alloc = GET_ALLO(HDRP(NEXT_BLKP(bp))); //check next block been allocated or not
	size_t size = GET_SIZE(HDRP(bp));

	if (prev_alloc && next_alloc)
		return bp;
	else if (prev_alloc && !next_alloc)
	{
		delete (bp);
		delete (NEXT_BLKP(bp));
		size += GET_SIZE(HDRP(NEXT_BLKP(bp)));
		PUT(HDRP(bp), PACK(size, 0));
		PUT(FTRP(bp), PACK(size, 0));
	}
	else if (!prev_alloc && next_alloc)
	{
		delete (bp);
		delete (PREV_BLKP(bp));
		size += GET_SIZE(FTRP(PREV_BLKP(bp)));
		PUT(FTRP(bp), PACK(size, 0));
		PUT(HDRP(PREV_BLKP(bp)), PACK(size, 0));
		bp = PREV_BLKP(bp);
	}
	else
	{
		delete (bp);
		delete (PREV_BLKP(bp));
		delete (NEXT_BLKP(bp));
		size += GET_SIZE(HDRP(NEXT_BLKP(bp))) + GET_SIZE(FTRP(PREV_BLKP(bp)));
		PUT(HDRP(PREV_BLKP(bp)), PACK(size, 0));
		PUT(FTRP(NEXT_BLKP(bp)), PACK(size, 0));
		bp = PREV_BLKP(bp);
	}

	insert(bp, size);
	return bp;
}

static void *place(void *bp, size_t asize)
{
	size_t csize = GET_SIZE(HDRP(bp));
	void *newptr = bp;
	delete(bp);
	if (csize - asize >= 2 * DSIZE) //the left space greater than the smallest block
	{
		PUT(HDRP(bp), PACK(asize, 1));
		PUT(FTRP(bp), PACK(asize, 1));
		bp = NEXT_BLKP(bp);
		PUT(HDRP(bp), PACK(csize - asize, 0));
		PUT(FTRP(bp), PACK(csize - asize, 0));
		insert(bp, csize - asize);
	}
	else
	{
		PUT(HDRP(bp), PACK(csize, 1));
		PUT(FTRP(bp), PACK(csize, 1));
	}
	return newptr;
}

/* 
static void *first_fit(size_t asize)
{
	void *bp;

	for (bp = heap_listp; GET_SIZE(HDRP(bp)) > 0; bp = NEXT_BLKP(bp))
	{
		if (!GET_ALLO(HDRP(bp)) && (asize <= GET_SIZE(HDRP(bp))))
			return bp;
	}
	return NULL;
}

static void *best_fit(size_t asize)
{
	void *bp, *bestbp = NULL;
	int size, min_size = 0;

	for (bp = heap_listp; (size = GET_SIZE(HDRP(bp)) != 0); bp = NEXT_BLKP(bp))
	{
		if (size >= asize && !GET_ALLO(HDRP(bp)) && (min_size == 0 || min_size > size))
		{
			min_size = size;
			bestbp = bp;
		}
	}
	return bestbp;
}
 */